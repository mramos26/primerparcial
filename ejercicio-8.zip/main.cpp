/******************************************************************************
8. Escriba un programa que acepte como entrada un número de cinco dígitos, lo separe en sus distintos dígitos y 
los imprima separándolos cada uno con tres espacios. (Sugerencia: emplee los operadores de división y de
módulo) Por ejemplo, si el usuario tecla 42339, el programa deberá imprimir:
*******************************************************************************/
#include<iostream>

using namespace std;
int main(){
    
    int numeros, digitos;
    cout<< "escribe un numero de cinco digitos""\n";
    
    cin>>numeros;
    
    digitos=numeros/10000;
    cout<<digitos<<"   ";
    
    digitos=numeros/1000%10;
    cout<<digitos<<"   ";
    
    digitos=numeros/100%10;
    cout<<digitos<<"   ";
    
    digitos=numeros/10%10;
    cout<<digitos<<"   ";
    
    digitos=numeros%10;
    cout<<digitos;
    
    
    return 0;
}
