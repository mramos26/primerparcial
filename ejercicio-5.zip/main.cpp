/******************************************************************************
Escriba un programa que lea cinco enteros y determine cuál es el más pequeño y cuál el más grande
imprimiéndolos en pantalla.
*******************************************************************************/
#include<iostream>
using namespace std;

int main()
{
    int n1, n2, n3, n4, n5, maximo, minimo;
    cout<<"ingresa numero 1:   ";
    cin>> n1; 
    
    cout<<"ingresa numero 2:   ";
    cin>> n2;
    
    cout<<"ingresa numero 3:   ";
    cin>> n3;
    
    cout<<"ingresa numero 4:    ";
    cin>> n4;
    
    cout<<"ingresa numero 5:    ";
    cin>> n5;
    
    if (n1>=n2 && n1>=n3 && n1>=n4 && n1>=n5){
        maximo = n1; 
    }   
        if (n1<=n2 && n1<=n3 && n1<=n4 && n1<=n5){
        minimo = n1;
    }
    
    else if (n2>=n1 && n2>=n3 && n2>=n4 && n2>=n5){
        maximo = n2;
    }    
      if (n2<=n1 && n2<=n3 && n2<=n4 && n2<=n5){
        minimo = n2;
    }
    
    else if (n3>=n1 && n3>=n2 && n3>=n4 && n3>=n5){
        maximo = n3;
    }    
       if (n3<=n1 && n3<=n2 && n3<=n4 && n3<=n5){
        minimo = n3;
    }
    
     else if (n4>=n1 && n4>=n2 && n4>=n3 && n4>=n5){
         maximo = n4;
     }    
      if (n4<=n1 && n4<=n2 && n4<=n3 && n4<=n5){
         minimo = n4;
    }
    
    else if (n5>=n1 && n5>=n2 && n5>=n3 && n5>=n4){
        maximo = n5;
    }    
    if (n5<=n1 && n5<=n2 && n5<=n3 && n5<=n4){
        minimo = n5;
    }
    
    
    cout<< "el numero mayor es << " <<maximo<< "\n" ; 
    cout<< "el numero minimo es << " <<minimo<< "\n" ;

    return 0;
}
