/******************************************************************************
7. Escriba un programa que lea dos enteros y determine si el primero es un múltiplo del segundo, y que
imprima el resultado (Sugerencia: utilice el operador de módulo)
*******************************************************************************/
#include<iostream>
using namespace std;

int main(){
    int n1, n2;
    
    cout<< "escriba el primer numero: " "\n";
    cin>>n1;
    
 
    cout << "escriba segundo numero:  " "\n";
    cin >> n2;
    
    if (n1 / n2 == 0);
    
    cout << " el numero "<< n1 << " es multiplo de " << n2 << "\n";{
        
if (n1 / n2 != 0); 

    }
    cout <<"el numero "<< n1 << " no es multiplo de " << n2 << "\n";
    


    return 0;
    
}
