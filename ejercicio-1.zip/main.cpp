/******************************************************************************
Escriba un programa completo que calcule e imprima el producto de tres enteros.
*******************************************************************************/

#include<iostream> 

using namespace std;

int main(){
    
    int n1, n2, n3, multiplicacion = 0;
    
    cout<<"dame primer numero: ";
    cin>>n1;
    cout<<"dame segundo numero: ";
    cin>>n2;
    cout<<"dame tercer numero: ";
    cin>>n3;
    
    multiplicacion = n1 * n2 * n3;
    
    cout<<"\nla multiplicacion es: "<<multiplicacion<<endl;
   return 0; 
}

