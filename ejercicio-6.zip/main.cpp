/******************************************************************************
6. Escriba un programa que lea un entero y determine si es par o non imprimiendo el resultado (Sugerencia:
utilice el operador de módulo. Un número par es un múltiplo de dos. Cualquier múltiplo de dos deja un residuo
de cero al dividirse entre 2)
*******************************************************************************/
#include<iostream>
using namespace std;
int main(){
    int numero;
    
    cout<<"escribe un numero:  ";
    cin>>numero;
    
    if(numero%2==0){
    cout<<"el numero es par";
    }
    
    else{
        cout<<"el numero es inpar";
    }
    
    
    
    
    
    
    
    
    
    return 0;
}