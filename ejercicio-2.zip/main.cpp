/******************************************************************************
un programa que le pida al usuario que introduzca dos enteros, que obtenga dichos enteros y que
imprima el número mayor seguido por las palabras “es mayor”. Si los números son iguales, que imprima el
mensaje “Estos números son iguales”;
*******************************************************************************/
 #include<iostream>
 
 using  namespace std;
 
 int main(){
     int n1, n2;
     
     cout<<"dame dos numeros: ";
     cin>> n1>>n2;
     
     if(n1==n2){
         cout<<"ambos numeros son iguales: ";
     }
         else if (n1>n2){
             cout<<"el mayor es: "<<n1;
         }
             else{
                 cout<<"el mayor es: "<<n2;
        
     }
     return 0;
 }

