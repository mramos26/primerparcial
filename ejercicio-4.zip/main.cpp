/******************************************************************************
Escriba un programa que acepte como entrada el radio de un círculo e imprima su diámetro, circunferencia
y área. Emplee el valor constante 3.14159 para p. Efectúe los cálculos en instrucciones de salida.
*******************************************************************************/

#include<iostream>

using namespace std;
int main()
{
    float radio, area, longitud, diametro, perimetro, circunferencia, pi=3.14159;
    cout<<"da el radio de la circunferencia   "<<endl;
    cin>>radio;
    perimetro=2*pi*radio;
    cout<<"EL PERIMETRO DE LA CIRCUNFERENCIA ES:"<<endl<<perimetro<< endl;
    
    area=pi*(radio * radio);
    cout<<"EL AREA DE LA CIRCUNFERENCIA ES:  "<<endl<<area<< endl;
    
    diametro=2*radio;
    cout<<"EL DIAMETRO DE LA CIRCUNFERENCIA ES:   "<<endl<<diametro<< endl;
    
    circunferencia=pi * diametro;
    cout<<"LA CIRCUNFERENCIA ES:   "<<endl<<circunferencia<< endl;
    
    return 0;
}
