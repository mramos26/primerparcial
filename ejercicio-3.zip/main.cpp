/******************************************************************************
Escriba un programa que acepte tres enteros del teclado e imprima la suma, el promedio, el producto y el
menor y mayor de ellos. El diálogo de la pantalla debe aparecer como sigue:
Teclee tres números enteros diferentes: 13 27 14
La suma es 54
El promedio es 18
El producto es 4914
El menor es 13
El mayor es 27
*******************************************************************************/

#include<iostream>

using namespace std;
int main(){
    int n1, n2, n3, producto=0, suma=0, promedio=0;
    
    cout<<"digitalice tres numeros diferentes " "\n";
    
   cin>> n1>>n2>>n3;
    
 
      suma=n1+n2+n3;
      cout<<"la suma es   "<<suma<<endl;
      
      promedio=(n1+n2+n3)/3;
      cout<<"el promedio es    "<<promedio<<endl;
      
      producto=n1*n2*n3;
      
      cout<<"el producto es  "<<producto<<endl;
      
       if (n1 < n2 && n1 < n3)
      cout <<"el menor es   " << n1 << endl;
      
     else if (n2 < n1 && n2 < n3)
      cout <<"el menor es   " << n2 << endl;
      
     else 
      cout <<"el menor es   " << n3 << endl;
     
      
   if (n1 > n2 && n1 > n3)
      cout <<"el mayor es   " << n1 << endl;
      
     else if (n2 > n1 && n2 > n3)
      cout <<"el mayor es   " << n2 << endl;
      
     else 
      cout <<"el mayor es   " << n3 << endl;
    
    
    return 0;
}
